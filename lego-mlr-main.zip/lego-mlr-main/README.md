# Lego Multiple Linear Regression Project
Multiple Linear Regression project using Lego data.
### Group Members
- Andrew Muller
- Adina
- George
- Huey
